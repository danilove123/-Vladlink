<?php
header("Content-Type:text/html;charset=UTF8");

include 'config.php';
include 'functions/functions.php';
$db = db(HOST,USER,PASS,DB);

$result = get_array($db);
echo "<div style='width:450px;padding:10px;border:1px solid #74776'>";
view_write($result,0,"",0,1,True);
echo "</div>";

?>
