-- Adminer 4.8.1 MySQL 8.0.34 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

USE `test`;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT,
  `url_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `alias` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_id` mediumint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `categories` (`id`, `url_name`, `alias`, `name`, `parent_id`) VALUES
(1,	'\\u041f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u0438',	'users',	'Пользователи',	0),
(2,	'\\u0421\\u043e\\u0437\\u0434\\u0430\\u043d\\u0438\\u0435',	'create',	'Создание',	1),
(3,	'\\u0421\\u043f\\u0438\\u0441\\u043e\\u043a',	'list',	'Список',	1),
(4,	'\\u0410\\u043a\\u0442\\u0438\\u0432\\u043d\\u044b\\u0435',	'active',	'Активные',	3),
(5,	'\\u0423\\u0434\\u0430\\u043b\\u0435\\u043d\\u043d\\u044b\\u0435',	'deleted',	'Удалённые',	3),
(6,	'\\u0417\\u0430\\u044f\\u0432\\u043a\\u0438',	'requests',	'Заявки',	0),
(7,	'\\u041e\\u0442\\u0447\\u0451\\u0442\\u044b',	'reports',	'Жалобы',	0),
(8,	'\\u041f\\u043e\\u0438\\u0441\\u043a',	'search',	'Поиск',	1),
(9,	'\\u0417\\u0430\\u044f\\u0432\\u043a\\u0438 \\u043d\\u0430 \\u043f\\u043e\\u043a\\u043b\\u044e\\u0447\\u0435\\u043d\\u0438\\u0435',	'connecting',	'Подключение',	6),
(10,	'\\u0417\\u0430\\u044f\\u0432\\u043a\\u0438 \\u043d\\u0430 \\u0440\\u0435\\u043c\\u043e\\u043d\\u0442',	'repairs',	'Восстановление',	6),
(11,	'\\u0417\\u0430\\u044f\\u0432\\u043a\\u0438 \\u043d\\u0430 \\u043e\\u0431\\u0445\\u043e\\u0434',	'round',	'Обход',	6),
(12,	'\\u041e\\u0442\\u0434\\u0435\\u043b \\u043c\\u0430\\u0440\\u043a\\u0435\\u0442\\u0438\\u043d\\u0433\\u0430',	'marketing',	'Маркетинг',	7),
(14,	'\\u0423\\u043f\\u0440\\u0430\\u0432\\u043b\\u0435\\u043d\\u0438\\u0435',	'control',	'Контроль',	7),
(15,	'\\u041e\\u0442\\u0447\\u0451\\u0442 \\u043f\\u043e \\u0441\\u043f\\u0438\\u0441\\u0430\\u043d\\u0438\\u044f\\u043c',	'write-offs',	'Списания',	12),
(16,	'\\u041e\\u0442\\u0447\\u0451\\u0442 \\u043f\\u043e \\u0440\\u0430\\u0441\\u0445\\u043e\\u0434\\u0430\\u043c',	'costs',	'Цены',	12),
(17,	'\\u0413\\u043e\\u0434\\u043e\\u0432\\u043e\\u0439 \\u043e\\u0442\\u0447\\u0451\\u0442',	'year',	'Год',	12),
(18,	'\\u041e\\u0442\\u0447\\u0451\\u0442 \\u043f\\u043e \\u044d\\u0444\\u0444\\u0435\\u043a\\u0442\\u0438\\u0432\\u043d\\u043e\\u0441\\u0442\\u0438 \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b',	'efficiency',	'Эффективность',	14),
(19,	'\\u041e\\u0442\\u0447\\u0451\\u0442 \\u043f\\u043e \\u043f\\u043e\\u0434\\u043a\\u043b\\u044e\\u0447\\u0435\\u043d\\u0438\\u044f\\u043c',	'connecting',	'Подключение',	14);

-- 2023-09-10 13:00:10
