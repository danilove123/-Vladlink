<?php
    function db($host,$user,$pass,$database){

        $db = mysqli_connect($host,$user,$pass);

        if(!$db){exit();}

        if(!mysqli_select_db($db,$database)){exit();}

        return $db;

    }

    function get_array($db){

        $sql = "SELECT `id`,`url_name`,`alias`,`name`,`parent_id` FROM  `categories`";
        $result = mysqli_query($db,$sql);

        if(!$result){return NULL;}

        $arr_c = array();
        if(mysqli_num_rows($result) != 0){

            for ($i = 0; $i < mysqli_num_rows($result);$i++){
                $row = mysqli_fetch_array($result,MYSQLI_BOTH);
                if(empty($arr_c[$row['parent_id']])){
                    $arr_c[$row['parent_id']] = array();
                }
                $arr_c[$row['parent_id']][] = $row;
            }

        }
        return $arr_c;
    }
    function view_write($arr,$parent_id = 0,$str,$num_1,$num_2,$mode){

        $str_1 = $str;
        $stroke = "";

        if(empty($arr[$parent_id])){
            return;
        }
        if($mode==False){

            if($num_1>=$num_2){
                return;
            }

            else {$stroke = str_repeat("  ", $num_1);}
        }

        echo "<ul>";
        $num_1 = $num_1 + 1;

        for($i = 0;$i < count($arr[$parent_id]);$i++) {

            $str = $str."/".$arr[$parent_id][$i]['alias'];

            $to_file = "<li><a href='?category_id=".$arr[$parent_id][$i]['id'].
            "&parent_id=".$parent_id."'>".$arr[$parent_id][$i]['name']." ".$str;

            echo $to_file;
            file_put_contents("type_a.txt",$stroke.$arr[$parent_id][$i]['name']." ".$str."\n",FILE_APPEND);

            view_write($arr,$arr[$parent_id][$i]['id'],$str,$num_1,$num_2,$mode);
            $str = $str_1;

            echo "</li>";

        }
        echo '</ul>';
    }

?>
