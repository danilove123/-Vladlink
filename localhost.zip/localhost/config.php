<?php
    define("HOST",'localhost');
    define("USER",'root');
    define("PASS",'password');
    define("DB",'test');
?>
